# DECISIONS.md — RADA AI Decision and Approval Log (v2)

MK records every decision here. Claude Code treats this file as binding and never edits an MK decision line. It may only add new open questions at the bottom of section B.

Line format: `D-nn: <decision> — MK, DD/MM/YYYY`

Each question includes Claude's recommendation. MK can write "ACCEPT RECOMMENDATION" or a different decision.

**⚠ = professional or legal judgment required. Take advice; do not rely on the recommendation alone.**

---

## A. CP-0 decisions (Monday 09/11/2026)

### D-01: First three pilots and accountable owner
*Portfolio §10.1.*
**Recommendation:**
- Assignment Control Tower (from the Clyde bake-off, CP-3), Document Intelligence Core (CP-4) and Virtual CFO Portal (CP-8).
- Owner of all three: MK (RADA).
- Clyde acceptance owner: the Managing Partner.

**MK decision:**

### D-02: Architecture centre
*Portfolio §10.2.*
**Recommendation:**
- Model-neutral with RADA's own portal. Anthropic adapter live first; OpenAI and Google behind the same gateway later.
- Default stack: Django/HTMX + Postgres + Redis/Celery.
- If the CP-2 base app uses a different stack, record it here.

**MK decision:**

### D-03: Contract between RADA AI and Clyde & Associates ⚠
**Recommendation:** a services agreement plus a data processing agreement that:
- covers work already delivered before RADA's incorporation as well as future work;
- names Clyde as data controller and RADA as data processor (Data Protection Act, 2019);
- limits use of client data to delivering the service, benchmarking on anonymised data, retention and deletion;
- requires Clyde's consent for any case study or reference.

**Also confirm:**
- that Clyde's engagement letters allow sub-processing;
- whether RADA must register with the ODPC;
- how cross-border transfer to model providers is handled.

**MK decision (and date signed):**

### D-04: Clyde benchmark sets
*Portfolio §10.3. Needed by Friday 27/11/2026, anonymised via B5.*
- **B1** mixed evidence set, 100–300 documents (one completed engagement)
- **B2** retainer ledger set: bank and M-Pesa statements, GL, completed recs (gold)
- **B3** completed audit or tax file with final workpapers (gold)
- **B4** one past tender plus the submitted response
- **B5** assignment register export

**MK decision (which engagements, delivery date):**

### D-05: Virtual CFO design partner consent ⚠
If the funded-project client is a Clyde client, consent goes through Clyde under the D-03 data processing agreement.
**Recommendation:** written consent before any of their data is used; build on synthetic data until then.
**MK decision:**

### D-06: First target segment and the 30-day demo
*Portfolio §10.5.*
**Recommendation:**
- Segment: small and mid-sized Kenyan audit and accounting firms (2–30 staff).
- Demo on Tuesday 08/12/2026: Assignment Control Tower + Document Intelligence Core.

**MK decision:**

### D-07: IP assignment register ⚠
This covers both the code written before RADA was incorporated (some possibly while MK was a Clyde employee) and each bake-off developer's code.

**Recommendation:**
- Written IP assignment to RADA from **each developer**, and from **Clyde** for anything Clyde may own (pre-incorporation work done as Clyde IT Lead).
- A licence back to Clyde for its own use.
- Confidentiality terms covering Clyde client data.
- No code is scored at the bake-off or ported into the hybrid until its status here is `ASSIGNED`.

| Source | Owner today (per advice) | Assignment signed? | Status (ASSIGNED / PENDING / EXCLUDED) |
|---|---|---|---|
| Pre-incorporation Clyde platform code | | | |
| App A developer | | | |
| App B developer | | | |
| App C developer | | | |

**MK decision:**

### D-08: Hosting, storage and approved model providers ⚠
**Recommendation:**
- The hybrid runs on RADA-controlled infrastructure (VPS + Cloudflare R2), with staging at `app.radaai.ai`.
- Clyde is tenant #1.
- Anthropic API only, with a dedicated RADA key, for the 90 days. Confirm the current data-retention and no-training terms.
- Data residency and cross-border transfer are covered under D-03.

**Also decide:** whether any existing Clyde-paid infrastructure or API keys transfer to RADA or remain Clyde's and are billed through.

**MK decision:**

### D-09: Capacity, budget and cadence
**Recommendation:**
- MK gives about 25 hours per week to RADA.
- Model cap: KES 20,000 per month during build.
- Infrastructure: KES [MK].
- Weekly review on Fridays (*portfolio §10.6*).

**Also state:** whether the Clyde pilot AI budget (KES 10–30k per month) is Clyde's spend through RADA or a RADA cost.

**MK decision:**

### D-10: Thresholds
**Recommendation:**
- Recon materiality: KES [MK].
- Analytical review threshold: [MK]% or KES [MK].
- MK notional hourly rate for X4: KES [MK].

**MK decision:**

### D-11: Bake-off developers and roles
**Needed:**
- the three developers (name or role, relationship to RADA or Clyde: member, staff, contractor);
- confirmation that MK is one of them;
- confirmation that everyone builds to `BAKEOFF_KIT.md` §2 from Friday 13/11/2026.

**Recommendation:** MK's app is App-labelled like the others, and MK does not score W4 or W7 alone.
**MK decision:**

### D-12: Bake-off rules
**Recommendation:**
- Freeze Friday 20/11/2026, 18:00 EAT.
- Panel: Managing Partner + MK + one independent reviewer if available.
- Model spend cap per developer: KES 3,000 for the bake-off.
- Synthetic data only (SYN-1).

**MK decision:**

### D-13: Scoring weights
**Recommendation:** as in `BAKEOFF_KIT.md` §6.2: governance 25%, traceability 15%, architecture 15%, functionality 20%, benchmark 10%, code quality 10%, usability 5%.
**MK decision:**

### D-14: Developers' role after the bake-off
**Options:**
- (a) MK alone with Claude Code.
- (b) The other two stay on to port their winning features (paid or in exchange for equity/other terms).

**Recommendation:** (b) for Phase 3 if affordable. It cuts the port effort and moves checkpoints earlier.
**MK decision:**

### D-15: Clyde cutover approach
**Recommendation:**
- Parallel run of the hybrid daily brief and register against whatever Clyde uses today for 10 working days.
- Switch over only after the outputs match and the Managing Partner approves in writing.
- No changes to Clyde's live system before then.

**MK decision:**

### D-16: Outbound messaging policy
**Recommendation:**
- **Internal** deterministic reports (for example, the daily brief) to allowlisted firm staff are allowed without per-message approval, via a registered agent with recipient allowlist and kill switch.
- Anything to Clyde's **clients** or third parties needs per-message human approval, in line with the portfolio §6 prohibition.

**MK decision:**

### D-17: Virtual CFO Portal shape
Clyde's earlier decision was WhatsApp-only interaction for retainer clients in v1.
**Options:**
- (a) Firm-facing portal plus WhatsApp to clients (with approval).
- (b) Client-facing portal for the funded-project design partner only.

**Recommendation:** (a) for Clyde, with a single client-facing login for the design partner if D-05 consent is given.
**MK decision:**

---

## B. Open questions raised by Claude Code
(`Q-nn (DD/MM/YYYY, raised at <task>): question / options / recommendation`)

---

## C. Checkpoint approvals
Format: `CP-n: APPROVED | APPROVED WITH CHANGES: <changes> | REJECTED: <reasons> — MK, DD/MM/YYYY`

CP-0:
CP-1:
CP-2 (base app selected: App __; port list approved; panel members):
CP-3 (portfolio governance baseline):
CP-4:
CP-5:
CP-6:
CP-7:
CP-8:
CP-9:
CP-10:

---

## D. Scope changes and cuts

## E. Exit criterion X5: Clyde responsible-professional confirmations
(Signed off by the Managing Partner or a designated partner, not MK.)
