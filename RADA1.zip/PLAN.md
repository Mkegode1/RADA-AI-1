# PLAN.md — RADA AI 90-Day Build Plan (v2: Bake-off → Hybrid → Portfolio Products)

**Source documents:**
- *RADA AI Implementation Opportunity Portfolio*: §8 (90-day plan), §6 (governance), §9 (measures), §10 (decisions).
- `BAKEOFF_KIT.md`: the three-app comparison.

**Day 1:** Monday 09/11/2026. **Day 90 (hard deadline):** Saturday 06/02/2027.
**Stretch goal:** finish every checkpoint before its target date.

---

## 1. Context and how this plan adapts the portfolio

- **RADA AI LIMITED** is the AI automation services company. **Clyde & Associates is its first pilot client.**
- The Clyde practice automation platform started before RADA AI was incorporated, but it is the same implementation RADA AI is delivering.
- **Three developers** are building independent versions. Their features will be compared, and the best features combined into **one hybrid app**.
- That hybrid becomes RADA AI's **common product backbone** (portfolio §5). Clyde is tenant #1, and later clients use the same chassis.
- RADA is otherwise run as a one-person operation by MK, with Claude Code as the automation engineer. MK's review time is the bottleneck.

| Portfolio element | How this plan delivers it |
|---|---|
| "Build a common backbone and configure it per workflow" (§5) | The bake-off winner becomes the chassis. Governance, model gateway, evidence and review layers are consolidated on it in Phase 3. |
| First three pilots (§8): Document Intelligence Core, Assignment Control Tower, Virtual CFO Portal | The Assignment Control Tower is largely the existing Clyde monitoring/daily-brief work, ported first (CP-3). Document Intelligence Core follows (CP-4) and the Virtual CFO Portal later (CP-8). |
| Governance baseline before write or communication rights (§10.4) | Governance conformance is 25% of the bake-off score, and governance is built or ported on the chassis before any new product work (CP-3). |
| 30-day demo (§10.5) | CP-4 on Tuesday 08/12/2026: Assignment Control Tower + Document Intelligence Core. |
| Retainer automation for Clyde (VAT, payroll, management accounts) | Delivered as the portfolio's Reconciliation and Close Agent (CP-6) and the Virtual CFO Portal (CP-8). |
| Pilot-grade by Day 90 | Benchmarks pass, products are demo-ready and governed. Production hardening and write actions are parked until after Day 90. |

### Capacity assumption
MK confirms this in D-09.
- MK gives RADA about 25 hours per week, including at least 1 hour per working day of review and 2 hours per checkpoint.
- If the other two developers stay on after the bake-off (D-14), port tasks are assigned to them and dates can move earlier.

### Calendar constraints
- Jamhuri Day: Saturday 12/12/2026.
- **Holiday window 23/12/2026–01/01/2027:** Claude Code-heavy work only, no checkpoints.

---

## 2. Master calendar

| CP | Name | Target date (Day) | Stretch date (Day) | Portfolio window |
|---|---|---|---|---|
| CP-0 | Kickoff and decisions | Mon 09/11/2026 (1) | same | Days 1–15 Foundation |
| CP-1 | Bake-off kit issued + governance pack draft | Fri 13/11/2026 (5) | Thu 12/11/2026 (4) | Days 1–15 |
| — | **Bake-off submission freeze** | **Fri 20/11/2026, 18:00 (12)** | fixed | Days 1–15 |
| CP-2 | Comparison complete, base selected, port list approved | Mon 23/11/2026 (15) | fixed | Days 1–15 |
| CP-3 | Hybrid chassis + governance baseline + Assignment Control Tower | Fri 04/12/2026 (26) | Wed 02/12/2026 (24) | Days 16–35 Prototypes |
| CP-4 | Document Intelligence Core pilot + **30-day demo** | Tue 08/12/2026 (30) | Mon 07/12/2026 (29) | Days 16–35 |
| CP-5 | Proposal and RFP Factory prototype | Fri 11/12/2026 (33) | Thu 10/12/2026 (32) | Days 16–35 |
| CP-6 | Reconciliation and Close pilot (Clyde retainer automation) | Tue 22/12/2026 (44) | Fri 18/12/2026 (40) | Days 36–60 Controlled pilots |
| — | Holiday window (build only, no gates) | 23/12/2026–01/01/2027 | — | — |
| CP-7 | Audit and Tax Workpaper Copilot pilot | Thu 07/01/2027 (60) | Tue 05/01/2027 (58) | Days 36–60 |
| CP-8 | Virtual CFO Portal MVP | Fri 22/01/2027 (75) | Tue 19/01/2027 (72) | Days 61–75 Client product |
| CP-9 | Product selection and pricing | Tue 26/01/2027 (79) | Mon 25/01/2027 (78) | Days 76–90 Launch |
| CP-10 | Launch readiness | Fri 05/02/2027 (89) | Mon 01/02/2027 (85) | Days 76–90 |

**Fridays:** weekly build review (`reviews/WEEK-nn.md`). The first one is due Friday 13/11/2026.

---

## 3. Target architecture of the hybrid (the shared backbone)

The bake-off winner is reshaped toward this structure in Phase 3. Where the winning base already has an equivalent, keep it and rename or adapt rather than rewrite.

```
core/          tenancy (Organization = client firm tenant), users, roles
governance/    AgentRegistry, ToolPermission, DataScope, ApprovalRequest, RecipientAllowlist,
               ActionLog (append-only), CostLedger, KillSwitch, governance dashboard
llm/           gateway.py (single door), adapters/, routing (config/model_routing.yaml),
               prompt registry, response cache
intake/        uploads, request lists, completeness
evidence/      Document Intelligence Core: detect → text → classify → extract → validate →
               dedupe → link (SourceRef, ExtractedFact)
knowledge/     methodology, templates, statutes, credentials; retrieval
tools/         deterministic: money (Decimal), ratios, recon engine, deadlines, Kenyan validators
review/        ExceptionQueue, ReviewDecision, Assumption, version diff
deliverables/  docx/xlsx/pptx generators + validation gate + DRAFT watermark
notify/        WhatsApp Cloud API direct + email fallback, behind governance (allowlist + approval)
products/      control_tower/  recon/  rfp/  workpapers/  vcfo/
evals/         SYN-1 + anonymised Clyde benchmarks, scorers, scorecard → reports/
bakeoff/       comparison artefacts (read-only after CP-2)
```

These map to the portfolio's eight backbone stages as follows:
- Intake → `intake`
- Evidence → `evidence`
- Knowledge → `knowledge`
- Reasoning → `llm`
- Deterministic tools → `tools`
- Review and approval → `review` + `governance`
- Deliverables → `deliverables`
- Control evidence → `ActionLog` + `CostLedger` + `evals`

---

## 4. Phase-by-phase tasks

Task format: **ID: Name** (estimated Claude Code days). Each task lists acceptance criteria (AC). *MK input* marks work only MK can do.

### PHASE 0: Kickoff (Day 1, Monday 09/11/2026) → CP-0

- **K1: Read the pack** (0.25d)
  - AC: Claude Code posts its understanding, the risks it sees, and the open D-items.
- **K2: MK records decisions D-01 to D-17** (*MK input*, about 2 hours)
  - D-07 (IP) and D-11 (developer roles) are the most urgent.
- **K3: RADA evaluation and hybrid repo scaffold** (0.5d)
  - An empty `rada-platform` repo with the control files, `evals/`, `bakeoff/`, CI and `Makefile`.
  - The hybrid code arrives at CP-2, when the base is selected.

**CP-0 gate:**
- D-items answered.
- Safe while waiting: B1, B4.

---

### PHASE 1: Bake-off kit and foundation (Days 1–15, 09/11–23/11) → CP-1, CP-2

These tasks don't depend on which app wins, so Claude Code does them while the three developers finish building.

- **B1: Finalise `BAKEOFF_KIT.md`** (0.5d)
  - Apply the D-12 and D-13 decisions, then produce the developer brief as one plain-English PDF or markdown.
  - AC: MK can send it to the developers unchanged.
- **B2: Synthetic benchmark SYN-1** (2d)
  - Per kit §4: a synthetic firm, 40 assignments, 5 retainer clients, 120 documents and the answer key.
  - AC: all three apps can ingest SYN-1 without real data, and the answer key is complete.
- **B3: Black-box evaluation harness** (1.5d)
  - Scripts that run each app's SYN-1 export (kit §3) against the answer key and score W2, W4 and W5 automatically.
  - Governance live-test script (W1): pause, budget cap, unapproved client send, cross-tenant read.
  - AC: the harness runs on a dummy export and produces a scorecard.
- **B4: Governance Toolkit document pack v1** (1.5d)
  - Files in `docs/governance/`: policy, risk assessment, approval design, data classification (Public / Internal / Confidential / Restricted-Client), operating procedures (kill-switch drill, incident response, credential revocation), test scripts.
  - The agent inventory and access matrix are generated later from the chassis registry.
  - AC: every portfolio §6 control area maps to at least one control and one test or procedure.
- **B5: Anonymiser** (1d)
  - Deterministic redaction of KRA PINs, Kenyan phone numbers, ID numbers, emails, account numbers and M-Pesa codes, plus an MK-supplied name list, with a redaction report.
  - Used later for the Clyde benchmarks (B1/B2/B3 in Phase 3+).
- **B6: Staging infrastructure** (1d)
  - RADA-controlled VPS (D-08), Docker Compose, Caddy TLS, nightly encrypted backups and a restore drill.

**CP-1 gate (Fri 13/11; stretch Thu 12/11):**
- Kit, SYN-1 and developer brief ready for MK to issue.
- Governance pack v1 ready for MK review.
- Safe while waiting: B3, B5, B6.

**Freeze (Fri 20/11, 18:00):** developers tag `bakeoff-final` and submit their packages (kit §5).

- **B7: Evaluate the three apps** (2d, 21/11–23/11)
  - MK labels the repos App A/B/C.
  - Claude Code runs the gates, the harness and code reviews, producing **identical-format evidence per app** (W1–W3, W5, W6).
  - The panel scores W4 and W7 after the demos (*MK and Managing Partner input*, about 3 hours).
- **B8: Comparison report** (0.5d)
  - `bakeoff/COMPARISON_REPORT.md` per kit §7: gates, scorecard, feature matrix, recommended base, port list with IP status, gaps and the Clyde live-ops cutover note.

**CP-2 gate (Mon 23/11, fixed date):**
- The panel approves the base app and the port list.
- MK confirms IP status for every ported item (D-07).
- Safe while waiting: none touching hybrid code. Only B4 polish.

---

### PHASE 3: Hybrid chassis and governance baseline (Days 16–26, 24/11–04/12) → CP-3

The work is the same whichever app wins, but effort depends on the gaps the comparison report identified. Estimates assume an average base.

- **H1: Import base app into `rada-platform`** (0.5d)
  - Preserve history if IP-cleared, otherwise import a clean snapshot.
  - Apply CI, lint and the architecture tests.
  - AC: the base runs in staging with SYN-1.
- **H2: Tenancy** (1d)
  - Organization as tenant on every client-data model, scoped managers, and a test proving cross-tenant reads fail.
  - Clyde = tenant #1; a SYN-1 demo firm = tenant #2.
- **H3: LLM gateway** (1d)
  - Route every model call through `llm.gateway.call()`: routing table, cache, KES cost, ActionLog.
  - Architecture test blocks direct SDK imports.
- **H4: Governance module** (2d)
  - AgentRegistry, ToolPermission, DataScope, RecipientAllowlist, ApprovalRequest, append-only ActionLog, CostLedger with caps, KillSwitch.
  - Governance test suite (7 tests): paused agent refused; tool outside allowlist refused; budget exceeded refused; client/third-party send without approval refused; ActionLog tamper fails; cross-tenant scope refused; global kill switch stops queued jobs.
  - Generate the agent inventory and access matrix into `docs/governance/`.
- **H5: Governance dashboard** (0.5–1d, port if the base or another app has one)
- **H6: Port list, wave 1 — Assignment Control Tower** (2–3d)
  - Assignment register, deterministic exception rules and the Managing Partner daily brief (metrics in code, validation gate, zero AI tokens on delivery, WhatsApp Cloud API direct + email fallback), taken from whichever app the report ranked best.
  - The brief goes only to allowlisted firm recipients (D-16).
  - AC:
    - The SYN-1 exception answer key matches 100%.
    - The brief validation gate blocks a seeded bad metric.
    - A send to a non-allowlisted number is refused.
- **H7: Clyde cutover plan** (0.5d)
  - Per D-15: parallel run of the hybrid brief against whatever is live for Clyde today, then a switch-over date proposed for MK and Managing Partner approval.

**CP-3 gate (Fri 04/12; stretch Wed 02/12):**
- Demo: governance tests run, an agent is paused, the daily brief runs on SYN-1, and the cutover plan is shown.
- **This is the portfolio's governance baseline approval (§10.4).**
- Safe while waiting: E1–E3 on SYN-1.

---

### PHASE 4A: Document Intelligence Core (Days 20–30, 28/11–08/12) → CP-4

This starts in parallel with H4–H6, because the evidence module is self-contained. Port from the bake-off apps where the report ranked an implementation highly.

- **E1: Ingestion** (0.5–1d)
  - Multi-file/zip upload, SHA-256 dedupe, tenant storage.
- **E2: Text extraction** (1–1.5d)
  - PDF text layer, vision for scanned pages, xlsx/csv with cell coordinates, eml/msg.
  - Nothing is dropped silently.
- **E3: Classification** (1d)
  - `config/doc_taxonomy.yaml`: bank statement, M-Pesa statement, sales/purchase invoice, contract/lease, KRA notice/assessment, iTax return/acknowledgement, tax compliance certificate, payroll, TB, GL, financial statements, minutes, correspondence, other.
  - AC: at least 90% accuracy on SYN-1, then on Clyde benchmark B1.
- **E4: Structured extraction** (2d)
  - Top 6 doc types, every field with a SourceRef.
  - Deterministic validators: totals, VAT arithmetic, KRA PIN format, DD/MM/YYYY dates, statement roll-forward.
  - AC: key-field accuracy of at least 95%; 100% SourceRef coverage.
- **E5: Near-duplicates and completeness** (0.5d)
  - Missing-items report against a request list.
- **E6: Evidence index UI** (1d)
  - Source highlight, confirm/correct per field, review-minutes timer.
- **E7: Pilot on Clyde benchmark B1** (0.5d)
  - Anonymised via B5, under D-03.

**CP-4 gate (Tue 08/12; stretch Mon 07/12): 30-day demo (portfolio §10.5)**
- Demo of the Control Tower plus the evidence pipeline to the D-06 target segment script.
- Safe while waiting: R1.

---

### PHASE 4B: Proposal and RFP Factory (Days 31–33, 09/12–11/12) → CP-5

This is first on the scope-cut ladder: it is listed as "Pilot next" in the portfolio's priority table.

- **R1: Requirement extraction from the tender** (1d)
  - Uses `evidence`. Includes the Kenyan tender checklist (TCC validity, incorporation certificate, CR12, ICPAK practising certificate, AGPO where relevant, bid security) as config for MK to verify.
  - AC: at least 95% recall of mandatory requirements on benchmark B4.
- **R2: Compliance matrix (xlsx) and response draft (docx)** (1d)
  - Claims link to the credentials library or are flagged `[MK TO CONFIRM]`.
- **R3: Submission check** (0.5d)
  - Deterministic checks; catches every seeded error.

**CP-5 gate (Fri 11/12; stretch Thu 10/12)**
- Safe while waiting: C1.

---

### PHASE 5A: Reconciliation and Close Agent = Clyde retainer automation (Days 36–44, 14/12–22/12) → CP-6

Port from the bake-off apps where possible (C5, C8 in the kit). The matching engine is deterministic; the LLM only explains exceptions.

- **C1: Normalise inputs** (1d)
  - Bank statements, M-Pesa business statements (charges separated), and the QBO GL export via read-only API or file.
  - AC: ties to source balances to the cent.
- **C2: Matching engine** (1.5d)
  - Passes: exact → fuzzy reference → one-to-many/many-to-one → timing.
  - AC: match rate at least that of the human rec on B2; **zero false matches above materiality (D-10).**
- **C3: Exception narratives and draft journals** (1d)
  - Dr = Cr validated in code; status DRAFT; no posting path exists.
- **C4: VAT and payroll working papers** (1.5d)
  - Rates and thresholds come from `config/kenya_tax.yaml` (`verified_by: MK` required).
  - Output is draft working papers only. **Filing on iTax stays a human action.**
- **C5: Reconciliation statement and close pack** (1d)
  - xlsx with live formulas, docx review pack with reviewer sign-off.

**CP-6 gate (Tue 22/12; stretch Fri 18/12):**
- Pilot on B2 (anonymised Clyde retainer data).
- Clyde reviewer feedback recorded.

---

### HOLIDAY WINDOW (23/12/2026–01/01/2027): Claude Code-heavy, MK optional

- **W1: Knowledge layer v1** (2d)
  - Kenyan statutes from Kenya Law, Clyde methodology and templates, and ISA/IFRS paragraph *references* plus MK summaries only.
  - Retrieval eval on 30 MK-written questions.
- **W2: Workpaper generator framework** (1.5d)
  - Every conclusion carries SourceRefs or Assumptions plus a reviewer decision; validation gate; docx sign-off table.
- **W3: Virtual CFO data model** (1d)
  - Models only; reuses the recon and close outputs.
- **W4: Hardening**
  - Tests, performance, backup restore drill #2.

---

### PHASE 5B: Audit and Tax Workpaper Copilot (Days 55–60, 02/01–07/01) → CP-7

Pilot on Clyde benchmark B3, limited to three workpaper types.

- **P1: Analytical review** (1.5d)
  - Ratios in code; frontier-model commentary with citations or open queries.
- **P2: IFRS 16 / IFRS 15 contract review memo** (1.5d)
  - Schedule maths in code.
- **P3: KRA tax audit / objection evidence pack** (1.5d)
  - Chronology, deadlines computed in code, evidence gaps, draft outline.
  - No submission path.
- **P4: Pilot run on B3** (0.5d)
  - Correction rate, unsupported claims, review minutes.

**CP-7 gate (Thu 07/01; stretch Tue 05/01)**

---

### PHASE 6: Virtual CFO Portal MVP (Days 61–75, 08/01–22/01) → CP-8

Clyde's v1 decision was that retainer clients interact via **WhatsApp only**. D-17 settles whether the portal is firm-facing first (staff view plus WhatsApp to clients) or client-facing for the funded-project design partner.

- **V1: Workspace and roles** (1.5d)
- **V2: Request list and document room** (1.5d)
  - Client uploads go into the evidence pipeline; requests via WhatsApp go through `notify/` with approval.
- **V3: Query and issue tracker** (1d)
- **V4: Close checklist** linked to recon (1d)
- **V5: Management dashboard** (2d)
  - KPIs in code, all in KES.
- **V6: Board pack / management accounts generator** (1.5d)
  - docx/pptx; commentary drafts tied to computed variances; DRAFT watermark; VCFO sign-off.
- **V7: Design-partner walkthrough** (*MK input*; consent per D-05)

**CP-8 gate (Fri 22/01; stretch Tue 19/01)**

---

### PHASE 7: Commercial launch (Days 76–90, 23/01–06/02) → CP-9, CP-10

- **L1: Demo tenant** on a synthetic Kenyan company, with one-command reset (1.5d).
- **L2: Product comparison scorecard** across all pilots, recommending the two strongest (0.5d).
- **CP-9 (Tue 26/01): product selection and pricing.**
  - MK picks two products and sets KES prices for the portfolio §7 models.
  - Claude Code supplies cost-to-serve figures from CostLedger.
  - **Pricing decisions are MK's.**
- **L3: Case studies** (1d)
  - Clyde as the reference client, **only with Clyde's written consent**; anonymised metrics.
- **L4: Outreach kit** (1.5d)
  - One-pagers, demo script, 10-slide deck, governance readiness questionnaire (the diagnostic offer).
- **L5: Readiness hardening** (2d)
  - OWASP review, dependency audit, restore drill #3, governance pack refresh, kill-switch drill.

**CP-10 gate (Fri 05/02; stretch Mon 01/02):** launch readiness.
- Both selected products pass the exit criteria.
- Demo works.
- Kit approved.
- Outreach begins.

---

## 5. Exit criteria

Every pilot must pass all of these (portfolio §9).

| # | Criterion | Threshold |
|---|---|---|
| X1 | Review-ready output on benchmark cases without material unsupported conclusions | ≥ 80% |
| X2 | Material claims, figures and calculations traceable to evidence or an explicit Assumption | 100% |
| X3 | Client/third-party communication, submission, posting or payment without configured approval | 0 |
| X4 | Net time saving after reviewer correction time and platform cost | Positive |
| X5 | **Clyde's responsible professional** (Managing Partner or a designated partner, not MK) confirms that capacity improves without loss of quality or accountability | Written, `DECISIONS.md` §E |
| X6 | Governance test suite | 100% pass |

---

## 6. Risk register

Claude Code reviews this weekly.

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| IP on pre-incorporation and developer code not assigned to RADA | High | High | D-07 before the freeze. Unassigned code is not scored or ported. Legal input. |
| MK's conflict of interest: Clyde IT Lead, RADA founder and one of the three developers | Certain | High | Written disclosure. Panel scoring with the Managing Partner. Anonymised App A/B/C evidence. Clyde-side acceptance by the Managing Partner. |
| Bake-off apps too divergent to port from cheaply | Medium | High | Shared spec and data contract issued Day 5. Base chosen on W1 + W3. Port only top-value features. |
| Disruption to Clyde's live operations during cutover | Medium | High | Parallel run; cutover approved by the Managing Partner (D-15). |
| Data protection (Clyde client data to model providers) | Medium | High | Services agreement and DPA (D-03). Anonymisation. Gateway enforces data classes. Legal input. |
| MK capacity | High | High | D-09. Scope-cut ladder. Use the other developers for ports if available (D-14). |
| Holiday slowdown | Certain | Medium | Planned Claude Code-only window. |
| Professional-content errors (tax rates, deadlines) | Medium | High | `kenya_tax.yaml` unverified until MK signs off; DRAFT watermarks; no opinions. |
| Scope creep | High | Medium | `BACKLOG.md`; scope added only at checkpoints. |

---

## 7. Safe pull-forward list

1. Extra doc types and schemas (E4 types 7–12).
2. W1 knowledge ingestion of public Kenyan statutes.
3. L1 synthetic demo dataset (extends SYN-1).
4. Tests and performance work.
5. Governance pack polish.
6. OpenAI and Google adapters behind the gateway (only if D-02 says model-neutral).

---

## 8. Scope-cut ladder

Cut from the top and record every cut in `DECISIONS.md` §D.
1. Defer the RFP Factory (CP-5) to after Day 90.
2. Drop the conversational WhatsApp query (C4) and keep the deterministic brief.
3. Reduce the Workpaper Copilot to two types (drop P2).
4. Reduce E4 to four doc types.
5. Make the VCFO MVP firm-facing only (request list + dashboard + management accounts).
6. Drop pptx and keep docx board packs.

**Never cut:** governance tests, traceability, approval enforcement, evals, the Clyde parallel run before cutover.

---

## 9. Parked until after Day 90

- **Actions:** client-facing outbound messaging without per-message approval, journal posting, iTax filing, QBO write.
- **Integrations and platform:** SSO, high availability, email ingestion, Drive/OneDrive connectors.
- **Portfolio "Pilot next" products:** KRA Tax Controversy Agent (beyond P3), Financial Statement Factory, Advisory Workbench, Compliance Horizon Scanner, VASP/AML Agent, Professional Judgment Simulator.
