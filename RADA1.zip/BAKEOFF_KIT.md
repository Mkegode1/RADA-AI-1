# BAKEOFF_KIT.md — Three-App Comparison and Hybrid Selection Kit

Three developers are building independent versions of the Clyde & Associates practice automation platform. That platform is RADA AI's first client implementation. This kit makes the comparison fair, measurable and aligned with the **RADA AI Implementation Opportunity Portfolio**. It also keeps the later merge cheap.

**Principle:** the hybrid is not a merge of three codebases. One app is selected as the **base** (the "chassis"), and the best features of the other two are **ported** into it, using only code whose IP has been assigned to RADA AI.

---

## 1. Rules for all three developers

Issue these at CP-1 (Friday 13/11/2026).

1. **Same specification.** Build to section 2 of this kit. Each developer can choose how to build a feature, but the scope is the same for everyone.
2. **Same data.** Use only the synthetic benchmark set (SYN-1) issued with this kit for development and demos. No real Clyde or client data goes into any repo, test, screenshot or demo.
3. **Same constraints.**
   - Model spend: KES cap per developer (see D-12).
   - No third-party messaging vendors (Meta WhatsApp Cloud API direct only).
   - Arithmetic happens in code, never in a model.
   - Nothing is sent to Clyde's clients.
4. **Submission freeze: Friday 20/11/2026, 18:00 EAT.** After the freeze, a git tag `bakeoff-final` is created and nothing changes until CP-2.
5. **IP and confidentiality.** Each developer signs the IP assignment and confidentiality terms in D-07 before submission. **Unassigned code is not scored and cannot be ported.**
6. **Independence.** Developers do not share code with each other before the freeze. MK is one of the three developers (see D-11), so MK does not score his own app alone; the panel does (section 6).

---

## 2. Shared requirements specification

Each item is mapped to the portfolio. "MUST" items are scored as pass/fail gates or weighted criteria. "SHOULD" items are bonus features.

### 2.1 Backbone (portfolio §5, eight stages)

| # | Requirement | Level | Portfolio ref |
|---|---|---|---|
| S1 | Intake: upload of PDFs, spreadsheets, images; batch upload | MUST | §5 stage 1 |
| S2 | Evidence processing: classify documents, extract fields, deduplicate | SHOULD | §3.1, §5 stage 2 |
| S3 | Every extracted figure links to its source (document + page/cell) | MUST | §5 stage 2, §6 traceability |
| S4 | Knowledge layer: firm templates/methodology stored and reused | SHOULD | §5 stage 3 |
| S5 | Model calls go through one routing layer; model choice by task; provider swappable | MUST | §5 stage 4, model routing |
| S6 | All calculations in deterministic code or spreadsheet formulas | MUST | §5 stage 5, §6 reproducibility |
| S7 | Review queue: named reviewer, approve/reject, change comparison | MUST | §5 stage 6 |
| S8 | Deliverables generated as docx/xlsx with live formulas, marked DRAFT | MUST | §5 stage 7 |
| S9 | Control evidence: log of inputs, model + version, actions, cost, approvals | MUST | §5 stage 8 |

### 2.2 Governance (portfolio §6, minimum standard)

| # | Control area | Requirement | Level |
|---|---|---|---|
| G1 | Ownership | Each agent/workflow has a named business owner, technical owner, reviewer | MUST |
| G2 | Identity | Separate credentials per agent/workflow; no shared staff passwords | MUST |
| G3 | Least privilege | Read-only by default; explicit tool and data allowlists | MUST |
| G4 | Action separation | Drafting components cannot change records | MUST |
| G5 | Human approval | Approval step before any message to a client/third party, submission, posting or payment | MUST |
| G6 | Traceability | See S3; assumptions recorded separately from sourced facts | MUST |
| G7 | Reproducibility | Saved formulas/code; versions and inputs retained | MUST |
| G8 | Monitoring | Full action log, exception alerts, cost limits | MUST |
| G9 | Shutdown | Workflow can be stopped and credentials revoked without model cooperation | MUST |
| G10 | Data protection | Client segregation (multi-tenant ready), encryption, no secrets in repo | MUST |
| G11 | Quality review | Can run the benchmark set and report accuracy | SHOULD |

### 2.3 Clyde functional scope (mapped to portfolio products)

| # | Feature | Portfolio product | Level |
|---|---|---|---|
| C1 | Assignment register: stages pitch → engaged → … → invoiced → paid; deadlines; fees | Assignment Control Tower §3.5 | MUST |
| C2 | Deterministic exception rules: overdue, stalled, completed-not-invoiced, unpaid 30/60/90 | Assignment Control Tower | MUST |
| C3 | Daily brief to the Managing Partner: metrics computed in code, validation gate, zero AI tokens on delivery path, WhatsApp Cloud API direct + email fallback | Assignment Control Tower | MUST |
| C4 | Conversational query of live firm data via WhatsApp (cheapest adequate model, cached) | Assignment Control Tower | SHOULD |
| C5 | Retainer workflow: bank/M-Pesa reconciliation, draft journals (never posted), VAT and payroll working papers | Reconciliation and Close §3.4 | SHOULD |
| C6 | Management accounts pack | Virtual CFO Portal §3.3 | SHOULD |
| C7 | Document generators (letters, engagement docs) | Audit/Tax Workpaper Copilot §3.2 (partial) | SHOULD |
| C8 | QBO read integration | Reconciliation and Close | SHOULD |

### 2.4 Prohibited in every app (portfolio §6)

Any instance found during review is an automatic **fail** on gate GATE-4.

- Autonomous KRA/iTax filing, objection submission or regulator correspondence.
- Journal posting, payment approval or bank instruction.
- Issuing an audit conclusion, tax opinion or client report without professional approval.
- Messages to clients or third parties without final human confirmation.
- Bypassing access restrictions or creating accounts.

---

## 3. Common data contract

All three apps export the following entities as JSON (`make export` or a documented command). This lets the panel compare outputs like for like, and lets the hybrid port features without rewriting data models.

| Entity | Minimum fields |
|---|---|
| Organization | id, name, kra_pin (synthetic in bake-off) |
| Client | id, organization_id, name, service_lines[] |
| Assignment | id, client_id, service_line, stage, partner, manager, staff[], key_dates{}, fee_kes, invoice_status, payment_status |
| Document | id, organization_id, client_id, filename, sha256, doc_type, uploaded_at |
| ExtractedFact | id, document_id, field, value, source_ref{page, bbox \| cell}, method, model, confidence |
| Assumption | id, related_to, text, owner |
| ReviewDecision | id, subject_type, subject_id, reviewer, decision, comment, decided_at |
| Agent | id, name, business_owner, technical_owner, reviewer, tools[], data_scopes[], budget_kes, status |
| ActionLog | id, agent_id, action, inputs_hash, model, prompt_version, tokens_in, tokens_out, cost_kes, result, at |
| JournalDraft | id, client_id, lines[{account, debit_kes, credit_kes}], status=DRAFT, source_refs[] |

Dates are DD/MM/YYYY in the UI and ISO 8601 in exports. Amounts are KES as decimal strings.

---

## 4. Synthetic benchmark set SYN-1

Claude Code builds this before CP-1. It is entirely fictional; no real names, PINs or numbers.

- A synthetic Nairobi audit firm with 40 assignments across all stages, including seeded exceptions with a known answer key.
- 5 synthetic retainer clients, each with:
  - 3 months of bank statements and M-Pesa business statements,
  - a GL export,
  - sales and purchase invoices,
  - a payroll summary,
  - one KRA notice.
- 120 mixed documents (text PDFs, scanned-style images, xlsx, csv), including seeded duplicates and missing items.
- An answer key (`SYN-1/answers/`) giving the expected exceptions, classifications, key fields, reconciliation result and brief metrics.

---

## 5. Submission package (due at the freeze)

1. Repo access for RADA's evaluation account, tagged `bakeoff-final`.
2. `README.md` with setup from clean in 30 minutes or less, using Docker Compose or documented steps.
3. `DEMO.md`: a 15-minute scripted demo against SYN-1.
4. A data-contract export for SYN-1 (section 3).
5. A self-assessment against sections 2.1–2.4. Each MUST is marked met, partial or not met, with file/line evidence.
6. A known-issues list.
7. A signed IP assignment and confidentiality agreement (D-07).

---

## 6. Scoring

### 6.1 Gates

These are pass/fail. Failing any gate means the app cannot be the base; its features can still be ported if they are IP-cleared.

| Gate | Test |
|---|---|
| GATE-1 | Runs from README in 30 minutes or less on a clean machine |
| GATE-2 | No real client data, secrets or credentials in the repo or git history |
| GATE-3 | IP assignment signed |
| GATE-4 | No prohibited capability (section 2.4) |

### 6.2 Weighted criteria

The weights below are draft and confirmed in D-13.

| # | Criterion | Weight | How measured |
|---|---|---|---|
| W1 | Governance conformance (G1–G11) | 25% | Checklist + Claude Code code review + live tests (pause workflow, exceed budget, attempt unapproved send) |
| W2 | Traceability and deterministic calculation (S3, S6) | 15% | Trace 20 random output figures to source; scan for model-generated arithmetic |
| W3 | Architecture fit to the 8-stage backbone, multi-tenant readiness, model-neutral routing (S1–S9) | 15% | Code review against `PLAN.md` §3 target architecture |
| W4 | Functional coverage (C1–C8) | 20% | Demo + SYN-1 answer key |
| W5 | Benchmark accuracy and cost (KES per SYN-1 run) | 10% | Automated run against the answer key |
| W6 | Code quality: tests, structure, docs, maintainability | 10% | Test count/coverage, lint, Claude Code review |
| W7 | Usability for the Managing Partner and staff | 5% | Panel scoring after demo |

Each criterion is scored 0–5. Weighted total = Σ(score/5 × weight).

### 6.3 Panel

- **Scorers for W4 and W7:** the Clyde Managing Partner (the client), MK, plus one independent reviewer if available (D-12).
- **Evidence for W1–W3, W5 and W6:** Claude Code produces it per app, in an identical format, without knowing who wrote which app. Repos are labelled App A/B/C by MK before analysis.
- **Base selection:** the panel picks the base by highest weighted total among apps that pass all gates. A tie goes to the higher W1 + W3 score, because a weak base is costly to fix.

---

## 7. Comparison report (Claude Code produces this for CP-2)

Saved as `bakeoff/COMPARISON_REPORT.md`. Sections:

1. Gate results per app.
2. Scorecard table (W1–W7) with evidence links.
3. **Feature-by-feature matrix:** for each S, G and C item, which app has the best implementation, and whether to keep (in the base), port (from another app) or discard.
4. **Recommended base**, with reasons.
5. **Port list:** each feature to port, from which app, estimated effort, IP status and the target hybrid phase in `PLAN.md`.
6. **Gaps:** MUST items no app meets well, to be built new on the chassis.
7. **Clyde live-operations note:** what is currently live for Clyde (for example, the daily brief) and the proposed cutover approach (D-15).
