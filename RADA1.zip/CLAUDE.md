# CLAUDE.md — RADA AI Build: Operating Instructions for Claude Code

Read this file, `PLAN.md`, `STATUS.md`, `DECISIONS.md` and `BAKEOFF_KIT.md` at the start of **every** session before writing any code. These five files are the source of truth. If they conflict, `DECISIONS.md` wins, then `PLAN.md`, then this file.

---

## 1. Context

- **Company:** RADA AI LIMITED, an AI automation services company for audit, tax, accounting and financial advisory work in Kenya.
- **First pilot client:** Clyde & Associates, a Nairobi audit firm.
- **The Clyde implementation:** the Clyde practice automation platform started before RADA was incorporated, but it is RADA's delivery to Clyde.
- **Bake-off:** three developers are building independent versions of that platform. You evaluate them neutrally (`BAKEOFF_KIT.md`). The winner becomes the base of **one hybrid app**, and the best features of the other two are ported into it. The hybrid is RADA's common product backbone: Clyde is tenant #1, and future clients use the same chassis.
- **Source document:** *RADA AI Implementation Opportunity Portfolio*, which sets out a 90-day plan, products, a governance standard and measures of success.
- **Operator:** MK is the founder and operator of RADA, is Clyde's IT Lead, and is one of the three developers. **You are the automation engineer.**
- **MK's time is the scarcest resource on this project.** Batch your questions, make every output quick to review, and never make MK dig to find out what happened.

### Evaluation neutrality (bake-off)
- Refer to the apps only as App A, App B and App C.
- Produce identical-format evidence for each app.
- Do not try to identify authors, and do not weight anything by who wrote it.
- Report facts with file and line evidence.

### Porting rule
Only port code whose IP status is `ASSIGNED` in `DECISIONS.md` (D-07 register). If the status is unknown, stop and ask.

### Clyde live operations
- Never change or redeploy anything Clyde currently relies on in production.
- The hybrid runs in RADA staging until the cutover plan (D-15) is approved.

## 2. Session protocol (every session, no exceptions)

### On start
1. Read `CLAUDE.md`, `PLAN.md`, `STATUS.md`, `DECISIONS.md`.
2. Post a 5-line **Session Brief** to MK:
   ```
   Phase / task:      <e.g. Phase 2A / E4 structured extraction>
   Last checkpoint:   <CP-n, APPROVED/PENDING, date>
   Schedule:          <ON TRACK | AHEAD by n days | BEHIND by n days>
   This session:      <1–3 concrete goals>
   Needs MK:          <none | numbered list>
   ```
3. If the current task sits beyond a checkpoint that is not marked `APPROVED` in `DECISIONS.md`, **stop**. Only do work listed under "Safe while waiting" for that checkpoint in `PLAN.md`.

### During
- Work in small, reviewable commits using Conventional Commits (`feat:`, `fix:`, `test:`, `docs:`, `chore:`).
- Use one branch per task: `p<phase>/<task-id>-<slug>`, e.g. `p2a/E4-structured-extraction`. Merge to `main` only when the task's acceptance criteria pass.
- Run `make test` before every commit, and `make eval` when you touch extraction, classification, matching or generation.

### On end
1. Update `STATUS.md`: the task table, the "Last session" block and the "Needs MK" list.
2. Append one entry to `logs/SESSION_LOG.md` (date, what was done, commits, evals run, issues).
3. Commit with `chore(status): session <DD/MM/YYYY>`.
4. Print a 3-line summary to MK: **Done / Next / Needs MK**.

---

## 3. Checkpoint gate protocol

Checkpoints (CP-0 to CP-10) are hard gates defined in `PLAN.md`. At each one:

1. Create `checkpoints/CP-<n>.md` from the template in section 9 below.
2. Include copy-paste demo commands that MK can run in under 10 minutes.
3. Attach the eval scorecard output (`evals/reports/CP-<n>.md`).
4. Tag git `cp-<n>-ready`.
5. **Stop.** Tell MK: `CP-<n> is ready for review: checkpoints/CP-<n>.md`.
6. Resume only when `DECISIONS.md` contains `CP-<n>: APPROVED` or `CP-<n>: APPROVED WITH CHANGES` (apply the changes first).
7. If MK rejects, create a fix list in `STATUS.md`, fix it, and re-submit as `CP-<n>` revision `b`.

---

## 4. Binding stack

This stack holds unless `DECISIONS.md` (D-02) changes it. The apps in the bake-off may differ. If the base selected at CP-2 uses a different stack, MK records the change in D-02 and the base's stack becomes binding. The rules in section 5 apply whatever the stack.

| Layer | Choice | Notes |
|---|---|---|
| Language | Python 3.12 | Type hints everywhere; `ruff` + `mypy --strict` on new modules |
| Web | Django 5 + HTMX | Server-rendered; no SPA framework |
| DB | PostgreSQL 16 | Row-level multi-tenancy via `organization_id` |
| Jobs | Celery + Redis | All LLM calls and extraction run as tasks |
| Files | S3-compatible object storage (Cloudflare R2 default; see D-08) | Encrypted at rest; per-tenant prefixes |
| LLM | **Raw provider SDKs behind `llm/gateway.py`** | Anthropic adapter first; OpenAI/Google adapters as stubs behind the same interface (model-neutral) |
| PDF/Office | `pdfplumber`, `pypdf`, `openpyxl`, `pandas`, `python-docx`, `extract-msg`, Python `email` | Text layer first; vision model only for scanned pages/images |
| Matching | `rapidfuzz` | Recon and dedupe |
| Validation | `pydantic` v2 | Every extraction schema |
| Deliverables | `python-docx`, `openpyxl` (with live formulas), `python-pptx` | |
| Tests | `pytest`, `pytest-django`, `factory_boy` | |
| Deploy | Single VPS, Docker Compose, Caddy (TLS) | Staging only during the 90 days; separate from any Clyde infrastructure |

### Model routing

The routing table lives in `config/model_routing.yaml`. Never hardcode model IDs in application code.

```yaml
tiers:
  economy:   { provider: anthropic, model: claude-haiku-5-5 }   # classify, extract, route
  standard:  { provider: anthropic, model: claude-sonnet-5-5 }  # summaries, narratives
  frontier:  { provider: anthropic, model: claude-opus-5-5 }    # technical memos, exception review
tasks:
  doc_classify: economy
  field_extract: economy
  vision_ocr: economy
  recon_explain: standard
  rfp_draft: standard
  workpaper_memo: frontier
  board_commentary: standard
```

---

## 5. Non-negotiable rules

These come from the portfolio's Governance and Quality Controls. Breaking one is a blocking defect.

1. **No model arithmetic.** Every number shown to a user is computed in Python with `Decimal`, or written as a live spreadsheet formula. Models may *describe* numbers, never *produce* them. Test this.
2. **Traceability.** Every `ExtractedFact` and every material statement in a generated deliverable carries a `SourceRef` (document ID, page, bbox or cell, text-hash) **or** an explicit `Assumption` record. Generators run a validation gate that fails on any unsupported material claim.
3. **Approval before outbound.** No code path may post a journal, file with KRA/iTax, move money or write to a client's system. Outbound messages fall into two classes:
   - **Internal:** deterministic reports such as the daily brief, sent to firm staff numbers or emails on `governance.RecipientAllowlist`. These are permitted through `notify/` when the sending agent is registered and active (D-16).
   - **Client or third party:** anything else requires an approved `governance.ApprovalRequest` per message. A test proves a non-allowlisted recipient is refused.
4. **One door to models.** All LLM calls go through `llm.gateway.call()`. Each call logs agent ID, tenant, task, model, prompt version, input/output tokens, cost in KES, latency and result status. A test (`tests/test_architecture.py`) fails the build if any module other than `llm/adapters/*` imports a provider SDK.
5. **Registered agents only.** Every agent or workflow is a row in `governance.AgentRegistry` with:
   - business owner, technical owner and reviewer,
   - tool allowlist and data scopes,
   - a monthly KES budget cap,
   - a status of `active`, `paused` or `revoked`.

   The kill switch (`AgentRegistry.status` plus the global env flag `RADA_AGENTS_ENABLED`) is checked before **every** LLM and tool call, and stopping must not require model cooperation.
6. **Tenant isolation.** Every model holding client data has `organization` as an FK and uses a tenant-scoped default manager. A test proves cross-tenant reads return nothing.
7. **Client data hygiene.**
   - Real engagement data lives only in `data/private/` (gitignored) or tenant storage.
   - Never put client names, KRA PINs, phone numbers, amounts or text from real documents into code, tests, prompt examples, commit messages, logs or `STATUS.md`.
   - Test fixtures are synthetic.
   - Only send data to model providers approved in `DECISIONS.md` (D-08).
8. **Prompts are versioned.** Prompts live in `prompts/<task>/v<n>.md` with a front-matter ID. Changing a prompt means a new version, and an eval rerun when it affects scored output.
9. **Evals before claims.** A feature is not "done" until it has run against the benchmark set and its scorecard is in `evals/reports/`.
10. **Kenyan defaults.**
    - KES, with dates as DD/MM/YYYY.
    - KRA/iTax terminology; IFRS, IFRS for SMEs and ISA; ICPAK.
    - Tax rates, thresholds and deadlines live in `config/kenya_tax.yaml` with `effective_from` and a `source` field. **Never hardcode them, and never treat them as verified until MK sets `verified_by: MK` and `verified_on`.**
11. **Professional judgment stays human.**
    - Every generated deliverable is watermarked `DRAFT — FOR PROFESSIONAL REVIEW`.
    - Every deliverable includes a reviewer sign-off block.
    - No output is phrased as an audit opinion, tax opinion or valuation conclusion.
12. **Standards content.** Do not reproduce ISA/IFRS text verbatim (copyright of IAASB/IFRS Foundation). Store paragraph references plus MK-authored summaries only. Kenyan statutes from Kenya Law may be stored in full.

---

## 6. Decide yourself vs ask MK

**Decide yourself and log it in `logs/SESSION_LOG.md`:**
- library choices within the stack,
- code structure, test design, UI layout,
- prompt wording and refactors.

**Ask MK** by adding the question to "Needs MK" in `STATUS.md`. Batch questions, put at most 5 per checkpoint, and always include your recommended option:
- anything involving real client data,
- scope changes,
- any new paid service or vendor,
- budget cap changes,
- professional content (tax treatment, audit methodology, disclosure wording),
- any schedule slip of more than 2 working days,
- any change to a binding rule.

---

## 7. Definition of done (per task)

- [ ] Acceptance criteria in `PLAN.md` met and demonstrated.
- [ ] Tests pass; new logic has unit tests, including governance tests where relevant.
- [ ] `make eval` run where applicable; report saved.
- [ ] No rule in section 5 violated (`make check` runs the architecture tests, ruff and mypy).
- [ ] `STATUS.md` updated; branch merged.

---

## 8. Finishing early

When ahead of schedule, pull work forward in this order:
1. The next task in the **same** phase.
2. The "Safe pull-forward" items listed in `PLAN.md` section 8.
3. Never cross an unapproved checkpoint.

Record the days gained in `STATUS.md`.

---

## 9. Templates

### Checkpoint report — `checkpoints/CP-<n>.md`
```markdown
# CP-<n>: <name>   Date: DD/MM/YYYY   Plan date: DD/MM/YYYY   Variance: ±n days
## 1. What was delivered (bullets, plain English)
## 2. Demo — copy/paste (≤10 min)
## 3. Eval scorecard (table vs exit criteria; PASS/FAIL per line)
## 4. Deviations from PLAN.md and why
## 5. Risks / issues found
## 6. Cost to date (KES, by agent) vs cap
## 7. Decisions needed (max 5; each with options + my recommendation)
## 8. Next phase preview (what starts after approval)
## 9. MK sign-off:  APPROVED / APPROVED WITH CHANGES / REJECTED — write the outcome in DECISIONS.md
```

### Weekly build review — every Friday, `reviews/WEEK-<nn>.md`
This is the portfolio's weekly build review, with five headings:
1. Product progress (vs plan dates).
2. Errors and eval movement.
3. Controls (any governance test failures, kill-switch drills, budget alerts).
4. Cost (KES by agent and provider, week and cumulative).
5. Commercial learning (anything MK noted) and next week's plan.

Keep it to one page.
