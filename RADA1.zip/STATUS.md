# STATUS.md — RADA AI Build Tracker (v2)

Claude Code updates this at the end of every session. MK reads it in 2 minutes.

**Today:** DD/MM/YYYY   **Day:** n / 90   **Phase:** 0   **Schedule:** ON TRACK
**Days gained (+) / lost (−):** 0   **Model spend this month:** KES 0 / cap KES [D-09]
**Bake-off freeze:** Friday 20/11/2026, 18:00 EAT — n days away

---

## Needs MK (most urgent first)
1. D-07 IP assignment register and D-11 developer roles. These block bake-off scoring.
2. D-03 services agreement + DPA (⚠ legal input).
3. Remaining D-items in `DECISIONS.md` (CP-0).

## Last session
- **Date:**
- **Done:**
- **Next:**
- **Blocked:**

---

## Checkpoints

| CP | Name | Target | Stretch | Status | Actual |
|---|---|---|---|---|---|
| CP-0 | Kickoff and decisions | 09/11/2026 | 09/11/2026 | NOT STARTED | |
| CP-1 | Bake-off kit issued + governance pack v1 | 13/11/2026 | 12/11/2026 | NOT STARTED | |
| — | Bake-off freeze | 20/11/2026 | fixed | — | |
| CP-2 | Comparison, base selected, port list | 23/11/2026 | fixed | NOT STARTED | |
| CP-3 | Hybrid chassis + governance baseline + Control Tower | 04/12/2026 | 02/12/2026 | NOT STARTED | |
| CP-4 | Document Intelligence Core + 30-day demo | 08/12/2026 | 07/12/2026 | NOT STARTED | |
| CP-5 | RFP Factory prototype | 11/12/2026 | 10/12/2026 | NOT STARTED | |
| CP-6 | Recon and Close (Clyde retainer automation) | 22/12/2026 | 18/12/2026 | NOT STARTED | |
| CP-7 | Workpaper Copilot pilot | 07/01/2027 | 05/01/2027 | NOT STARTED | |
| CP-8 | Virtual CFO Portal MVP | 22/01/2027 | 19/01/2027 | NOT STARTED | |
| CP-9 | Product selection and pricing | 26/01/2027 | 25/01/2027 | NOT STARTED | |
| CP-10 | Launch readiness | 05/02/2027 | 01/02/2027 | NOT STARTED | |

Status values: `NOT STARTED`, `IN PROGRESS`, `READY FOR REVIEW`, `APPROVED`, `REJECTED (rev b)`

---

## Current phase tasks

| ID | Task | Est. | Status | Notes |
|---|---|---|---|---|
| K1 | Read pack | 0.25d | NOT STARTED | |
| K2 | MK decisions D-01 to D-17 | MK | NOT STARTED | |
| K3 | Repo scaffold | 0.5d | NOT STARTED | |
| B1 | Finalise bake-off kit + developer brief | 0.5d | NOT STARTED | |
| B2 | Synthetic benchmark SYN-1 | 2d | NOT STARTED | |
| B3 | Black-box eval harness | 1.5d | NOT STARTED | |
| B4 | Governance Toolkit pack v1 | 1.5d | NOT STARTED | |
| B5 | Anonymiser | 1d | NOT STARTED | |
| B6 | Staging infrastructure | 1d | NOT STARTED | |
| B7 | Evaluate Apps A/B/C | 2d | NOT STARTED | after freeze |
| B8 | Comparison report | 0.5d | NOT STARTED | |

---

## IP clearance (mirror of D-07)

| Source | Status |
|---|---|
| Pre-incorporation code | PENDING |
| App A | PENDING |
| App B | PENDING |
| App C | PENDING |

## Latest eval scorecard

## Risks flagged this week
