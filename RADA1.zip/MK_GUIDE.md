# MK_GUIDE.md — How to Run This Build with Claude Code

This guide is for MK and is written in plain English. Claude Code does not need it, but it does no harm if Claude Code reads it.

---

## 1. One-time setup (about 1 hour, before Monday 09/11/2026)

1. **Install the prerequisites on Windows.**
   - Turn on WSL2 and install Ubuntu, then do the build inside Ubuntu. Django, Celery and Docker behave far better there.
   - Install **Docker Desktop** with "Use WSL2 engine" ticked.
   - Install **Git**.
   - Install **Claude Code** inside Ubuntu.
2. **Create the repository.**
   - Create a private GitHub repo called `rada-platform`, owned by a RADA AI account (not Clyde; see D-07).
   - Keep this repo separate from your own bake-off app. Claude Code evaluates all three apps from here, so your own app should be in its own repo like the other two.
   - In Ubuntu: `mkdir ~/rada-platform && cd ~/rada-platform && git init`
3. **Copy in the pack.** Put these five files in the repo root: `CLAUDE.md`, `PLAN.md`, `STATUS.md`, `DECISIONS.md`, `BAKEOFF_KIT.md`. Keep this guide wherever you like.
4. **Create a dedicated RADA Anthropic API key.** Do not reuse any Clyde key, because the governance rule is separate credentials per workflow.
   - Set a monthly spend limit in the Anthropic console that matches D-09.
   - The key goes into `.env` only. Claude Code creates `.env.example`; you copy it to `.env` and paste the key yourself.
5. **Block time in your calendar.**
   - 30 minutes every working day for review.
   - 1 hour every Friday for the weekly build review.
   - 2 hours on each checkpoint date (see the table in `STATUS.md`).

---

## 2. Your routines

**Daily (about 15 minutes)**
1. Open `STATUS.md` and read "Needs MK" and "Last session".
2. Answer anything in "Needs MK" by writing in `DECISIONS.md`, section B.
3. Start Claude Code with the **Resume** prompt (section 3).

**Friday (about 1 hour)**
1. Read `reviews/WEEK-nn.md`.
2. Check cost against the cap and look at the risk list.
3. Note any commercial learning, such as conversations with prospects, in the review file.

**Checkpoint day (1–2 hours)**
1. Open `checkpoints/CP-n.md`.
2. Run the demo commands it lists (under 10 minutes).
3. Read the scorecard. Every line should say PASS.
4. Answer the decisions it raises (5 at most).
5. Write your verdict in `DECISIONS.md`, section C, for example:
   `CP-2: APPROVED — MK, 04/12/2026`
6. Tell Claude Code: "CP-2 decision recorded. Continue."

**Rule of thumb:** if a checkpoint review takes more than 2 hours, tell Claude Code its checkpoint reports are too heavy, and it will simplify them.

---

## 3. Prompt library (copy and paste)

### Kickoff (first session only)
```
Read CLAUDE.md, PLAN.md, STATUS.md, DECISIONS.md and BAKEOFF_KIT.md in full.
Then:
1. Give me your understanding of the plan in 10 bullets or fewer.
2. List anything in the plan you think is unrealistic, ambiguous or risky, with a fix for each.
3. List the CP-0 decisions I still need to make (D-01 to D-17), each with your recommendation in one line.
Do not write code yet. Wait for my go-ahead.
```

### Go-ahead after the CP-0 decisions
```
I have completed the D-items in DECISIONS.md and recorded CP-0: APPROVED.
Start K3 (repo scaffold), then Phase 1 in task order (B1 to B6).
Follow the session protocol in CLAUDE.md and stop at CP-1.
```

### Resume (every session)
```
Resume. Follow the session protocol in CLAUDE.md: read the four control files,
give me the Session Brief, then continue the current task.
Stop at the next checkpoint gate or when you need me.
```

### Checkpoint approved
```
CP-<n> decision recorded in DECISIONS.md. Apply any changes listed,
update STATUS.md with the next phase's task table, then continue.
```

### I'm behind / low on time this week
```
I only have <n> hours this week. Re-plan the current phase using the scope-cut ladder in PLAN.md section 9.
Show me the proposed cuts and the new dates before changing anything.
I will record the approved cuts in DECISIONS.md section D.
```

### We're ahead
```
We're ahead. Pull forward work per CLAUDE.md section 8 (same-phase tasks first,
then the safe pull-forward list). Do not cross any unapproved checkpoint.
Record the days gained in STATUS.md.
```

### Something feels off
```
Stop current work. Give me a plain-English audit of the last <n> sessions:
what was built, what tests and evals were run, what deviated from PLAN.md,
and any rule in CLAUDE.md section 5 that might be at risk. No code changes.
```

### Evaluate the bake-off (after the freeze)
```
The freeze has passed. The three submissions are in bakeoff/app-a, bakeoff/app-b and bakeoff/app-c.
Run task B7 per BAKEOFF_KIT.md section 6: gates, harness, governance live-tests and code reviews,
with identical-format evidence per app. Refer only to App A/B/C. Score only apps whose IP status is
ASSIGNED in DECISIONS.md D-07. Then produce B8 (COMPARISON_REPORT.md) and stop at CP-2.
```

### Start the hybrid (after CP-2)
```
CP-2 approved: base is App <X>, and the port list is approved in DECISIONS.md.
Start Phase 3 (H1 to H7). Do not touch anything Clyde uses live. Stop at CP-3.
```

### Weekly review (Friday)
```
Produce this week's build review per CLAUDE.md section 9 (reviews/WEEK-<nn>.md),
update the risk register status, and give me the 5-line summary here.
```

---

## 4. What only you can do

Claude Code will ask you for these. Have them ready early to protect the dates.

| Item | Needed by | Why |
|---|---|---|
| D-07 IP assignments + D-11 developer roles | Mon 09/11/2026 | Nothing is scored or ported without these |
| Remaining D-items | Mon 09/11/2026 | Gate CP-0 |
| Issue the bake-off kit to all three developers | Fri 13/11/2026 | Fair, comparable apps |
| Services agreement + DPA with Clyde, plus legal advice (D-03) ⚠ | Wed 18/11/2026 | No real Clyde data before this |
| Repo access to all three apps + labelling them App A/B/C | Sat 21/11/2026 | Evaluation |
| Panel demo session (you, the Managing Partner, independent reviewer) | Sun 22/11–Mon 23/11/2026 | W4/W7 scores, CP-2 |
| Name list for the anonymiser + Clyde benchmark sets B1–B5 | Fri 27/11/2026 | Pilots on real (anonymised) data |
| Cutover approval from the Managing Partner (D-15) | After the parallel run | Hybrid replaces anything live |
| Verify `kenya_tax.yaml` | Fri 18/12/2026 | Recon, VAT, payroll |
| Methodology/templates + 30 test questions | 01/01/2027 | Knowledge layer |
| VCFO design-partner consent (D-05) | Fri 08/01/2027 | Phase 6 on real data |
| Clyde's X5 sign-offs (Managing Partner, not you) | Each pilot checkpoint | Exit criteria |
| Prices in KES | Tue 26/01/2027 | CP-9 |

---

## 5. Warning signs (tell Claude Code to stop if you see any)

- Any number in an output that was not produced by code or a spreadsheet formula.
- Any feature that sends, posts, files or pays, even "just for testing".
- Real client names, PINs or amounts appearing in code, commits, logs or `STATUS.md`.
- A task marked done with no eval report.
- Work starting on a phase whose checkpoint you have not approved.
- Code ported from an app whose IP status is not ASSIGNED.
- Any change to something Clyde uses live before the cutover is approved.
- `STATUS.md` not updated at the end of a session.
